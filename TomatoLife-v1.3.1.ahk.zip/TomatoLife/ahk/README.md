# Tomato-Life-AHK

25+5 循环番茄工作法

## 工作方式

每小时25分和55分，进入休息模式，自动创建新的空桌面，此时请休息5分钟

然后00分和30分，进入工作模式，删掉新的空桌面，返回桌面1

## 安装

```bat
REM 下载本项目源码
git clone https://github.com/snomiao/Tomato-Life-AHK

REM 配置自启动（并自动运行一次）
auto-start-enable.bat
```

## 原理
AutoHotkey实现

## 协议

GPLv3